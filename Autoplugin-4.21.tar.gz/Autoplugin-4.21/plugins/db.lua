--Plugins Online

db = {

--Kernel
{ path = "nonpdrm.skprx",				version = "0001", stringversion = "1.2" },
{ path = "nopsmdrm.skprx",				version = "0001", stringversion = "1.4" },
{ path = "vitabright.skprx",			version = "0001", stringversion = "1.0" },
{ path = "noavls.skprx",				version = "0001", stringversion = "0.1" },
{ path = "repatch.skprx",				version = "0001", stringversion = "3.0" },
{ path = "lolicon.skprx",				version = "0001", stringversion = "1.0.1.1" },
{ path = "ds3vita.skprx",				version = "0001", stringversion = "0.3" },
{ path = "ds4vita.skprx",				version = "0001", stringversion = "1.2" },
{ path = "udcd_uvc.skprx",				version = "0001", stringversion = "1.25" },
{ path = "viimote.skprx",				version = "0001", stringversion = "1.2" },
--{ path = "kuio.skprx",				version = "0001", stringversion = "1.2" },
{ path = "dsmotion.skprx",				version = "0001", stringversion = "1.2" },
{ path = "usbmc.skprx",					version = "0001", stringversion = "0.6" },
{ path = "AnalogsEnhancer.skprx",		version = "0001", stringversion = "1.0" },
{ path = "ioplus.skprx",				version = "0001", stringversion = "0.1" },
{ path = "vitacheat.skprx",				version = "0001", stringversion = "1.1" },
{ path = "noPsmWhitelist.skprx",				version = "0001", stringversion = "1.0" },
{ path = "AnalogStickDisable.skprx",				version = "0001", stringversion = "1.1" },
{ path = "cidSpoof.skprx",				version = "0001", stringversion = "1.0" },

--Boot_config.txt
{ path = "custom_boot_splash.skprx",	version = "0001", stringversion = "1.0" },

--Main
{ path = "download_enabler.suprx",		version = "0001", stringversion = "0.5" },
{ path = "nolockscreen.suprx",			version = "0001", stringversion = "0.2" },
{ path = "notrophymsg.suprx",			version = "0001", stringversion = "0.1" },
{ path = "custom_warning.suprx",		version = "0001", stringversion = "0.2" },

{ path = "shellbat.suprx",				version = "0001", stringversion = "0.9" },
{ path = "shellsecbat.suprx",			version = "0001", stringversion = "0.9" },
{ path = "pngshot.suprx",				version = "0001", stringversion = "1.3" },
{ path = "vflux.suprx",					version = "0001", stringversion = "0.5" },
{ path = "AutoBoot.suprx",					version = "0001", stringversion = "1.2" },
{ path = "jav.suprx",					    version = "0001", stringversion = "2.0.0" },
  

--All
{ path = "vsh.suprx",					version = "0001", stringversion = "3.4" },
{ path = "vitagrafix.suprx",			version = "0001", stringversion = "4.1.1" },
{ path = "oclockvita.suprx",			version = "0001", stringversion = "1.2.1" },
{ path = "Framecounter.suprx",			version = "0001", stringversion = "1.2" },
{ path = "VGi.suprx",			version = "0001", stringversion = "0.4" },
{ path = "FuckPSSE.suprx",			version = "0001", stringversion = "1.1" },
{ path = "PSMPatch.suprx",			version = "0001", stringversion = "1.1" },
{ path = "itls.suprx",			version = "0001", stringversion = "2.0" },
{ path = "trophax2.0.suprx",			version = "0001", stringversion = "2.0" },
{ path = "TurboPad.suprx",			version = "0001", stringversion = "0.3" },
{ path = "reRescaler.suprx",			version = "0001", stringversion = "1.0" },
{ path = "InfiniteNet.suprx",			version = "0001", stringversion = "1.0" },
{ path = "FreePSM.suprx",			version = "0001", stringversion = "1.1" },
{ path = "MakePsmGreatAgain.suprx",				version = "0001", stringversion = "1.4" },





}
